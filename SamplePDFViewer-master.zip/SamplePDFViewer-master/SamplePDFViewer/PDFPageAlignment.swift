enum PDFPageAlignment {

	case center
	case left
	case right
	
}
