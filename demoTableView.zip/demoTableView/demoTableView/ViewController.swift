//
//  ViewController.swift
//  demoTableView
//
//  Created by DINH VAN TIEN on 11/7/18.
//  Copyright © 2018 DINH VAN TIEN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
}

